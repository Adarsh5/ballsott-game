# 🎮 Ball Sort Puzzle — GitHub se FREE APK Banao
## (Sirf 5 Steps — Koi coding nahi!)

---

## 📁 Step 1 — game.html copy karo assets mein
`game.html` ko is folder mein daalo:
```
android/app/src/main/assets/game.html
```

---

## 🐙 Step 2 — GitHub Account banao (Free)
1. https://github.com → Sign Up (free)
2. Email verify karo

---

## 📤 Step 3 — Project Upload karo

### Option A — GitHub Website se (easiest):
1. github.com pe jao → **"New Repository"** click karo
2. Name: `ballsort-game` → **Create repository**
3. **"uploading an existing file"** link click karo
4. Poora `android/` folder drag & drop karo
   ⚠️ `.github/` hidden folder bhi include karo!
5. **"Commit changes"** click karo

### Option B — Git command se (PC pe):
```bash
git init
git add .
git commit -m "Ball Sort Game"
git branch -M main
git remote add origin https://github.com/TUMHARA_USERNAME/ballsort-game.git
git push -u origin main
```

---

## ⚙️ Step 4 — GitHub Actions check karo
1. Apna repository kholo
2. **"Actions"** tab click karo
3. **"Build BallSort APK"** workflow dikh raha hoga
4. ⏳ 3-5 minute wait karo (green tick aayega ✅)

---

## 📱 Step 5 — APK Download karo!
1. Actions → Latest run click karo
2. Neeche **"Artifacts"** section mein jao
3. **"BallSort-APK"** download karo → ZIP milega
4. ZIP extract karo → `app-debug.apk` milegi
5. Phone mein install karo! 🎉

---

## 💰 Meta Ads Add karne ke liye:
`MainActivity.java` line 16-17 pe apne IDs daalo:
```java
private static final String BANNER_ID       = "APNA_BANNER_ID";
private static final String INTERSTITIAL_ID = "APNA_INTERSTITIAL_ID";
```

IDs kahan se milenge:
→ business.facebook.com → Monetization Manager → Create App

---

## 🔄 Game Update kaise karein?
`game.html` update karo → GitHub pe push karo → Auto APK build! ✅

---

## ❓ Problems?
- Actions fail? → `.github/workflows/build.yml` sahi jagah hai?
- APK install nahi? → Settings → Unknown Sources → Allow
- Ads nahi dikh rahe? → Real Placement IDs daale ya nahi?

*Total cost: ₹0 (FREE!) 🎉*
